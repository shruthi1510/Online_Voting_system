# Voting System - README

## Overview

The Voting System is a web application that facilitates the management of elections, candidates, and voters. It provides two panels - an **Admin Panel** and a **User Panel**. The Admin Panel is designed for administrators to handle the overall election management, including creating and editing elections, managing candidates, and viewing user details. The User Panel is for voters to view active elections, cast votes, and participate in the democratic process.

## Technologies Used

- **Spring Boot**: The application is developed using the Spring Boot framework for building robust Java-based applications.
- **Thymeleaf**: Thymeleaf is used as the template engine for server-side rendering of HTML pages.
- **Spring Security**: Security features are implemented using Spring Security to manage user authentication and authorization.
- **MySQL Database**: MySQL is used as the relational database management system to store user information, election details, and voting data.

## Admin Panel

### 1. List Elections

- **Endpoint**: `/admin/listelection`
- Displays a list of all elections.
- Admins can view the details of each election.

### 2. Create Election

- **Endpoint**: `/admin/createElection`
- Allows admins to create a new election with a title, description, and start/end dates.
- Validates the election dates to ensure the end date is after the start date and in the future.

### 3. Edit Election

- **Endpoint**: `/admin/editElection/{id}`
- Admins can edit the details of an existing election.

### 4. Delete Election

- **Endpoint**: `/admin/deleteElection/{id}`
- Admins can delete an election, including all associated candidates and votes.

### 5. List Candidates

- **Endpoint**: `/admin/listcandidates/{electionId}`
- Displays a list of candidates for a specific election.

### 6. Add Candidate

- **Endpoint**: `/admin/addCandidate/{electionId}`
- Allows admins to add a candidate to a specific election.

### 7. Display Vote Count

- **Endpoint**: `/admin/candidates/vote-count`
- Shows the vote count for each candidate across all elections.

### 8. User Management

- **Endpoint**: `/admin/users`
- Admins can view and manage user accounts, including editing user details, toggling user status, and resetting passwords.

## User Panel

### 1. Home

- **Endpoint**: `/user/home`
- Home page for logged-in users.

### 2. View Active Elections

- **Endpoint**: `/user/elections`
- Displays a list of active elections available for voting.

### 3. Vote

- **Endpoint**: `/user/vote/{electionId}`
- Allows users to cast their votes for candidates in a specific election.

### 4. Already Casted

- **Endpoint**: `/user/already-casted`
- Shown if a user has already casted a vote.

### 5. Logout

- **Endpoint**: `/logout`
- Logs out the user.

## Registration

### 1. User Registration

- **Endpoint**: `/registration`
- Allows users to register accounts with the system.

## Access Denied

### 1. Inactive User

- **Endpoint**: `/inactive`
- Shown if a user tries to log in but their account is inactive.

## Notes on Database Queries

- The README includes default queries for creating the database, updating roles, and updating user status.
- Admins can update the status of users, activate users, and reset passwords.

```create database testv4;

use testv4;

show tables;


check any user Role: by emailId():

SELECT a.email, r.name, r.id AS role
FROM user a
JOIN users_roles ur ON a.id = ur.user_id
JOIN role r ON ur.role_id = r.id
WHERE a.email = 'Demo1@gmail.com';


Update Status:
UPDATE `testv4`.`user` SET `active` = true WHERE (`id` = 11);
UPDATE `testv4`.`role` SET `name` = 'ROLE_ADMIN' WHERE (`id` = '11');

```

