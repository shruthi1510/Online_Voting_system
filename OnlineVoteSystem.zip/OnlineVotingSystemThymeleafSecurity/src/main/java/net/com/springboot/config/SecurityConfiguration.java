
package net.com.springboot.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.bind.annotation.GetMapping;

import net.com.springboot.model.User;

import net.com.springboot.service.UserService;
@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Autowired
    private UserService userService;

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    @Autowired
    private CustomAuthenticationFailureHandler customAuthenticationFailureHandler;

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
        auth.setUserDetailsService(userService);
        auth.setPasswordEncoder(passwordEncoder());
        return auth;
    }



    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(authenticationProvider());
           
    }

    @Override
    
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests(requests -> requests
        		 .antMatchers("/").permitAll()
                .antMatchers("/login","/inactive").permitAll()
                .antMatchers("/successHandler").permitAll()
                .antMatchers("/admin/**").hasAnyRole("ROLE_ADMIN","ADMIN")
                .antMatchers("/user/*").hasAnyRole("ROLE_ADMIN","ROLE_USER","USER")
                .antMatchers("/admin/login/").permitAll()
                .antMatchers(
                        "/registration**",
                        "/js/**",
                        "/css/**",
                        "/img/**"
                ).permitAll()
                .anyRequest().authenticated())
                .formLogin(login -> login
                        .loginPage("/login")
                      
                        .successHandler((request, response, authentication) -> {
                        
                             
                               
                                User user = userService.getCurrentUser();
                                if (user != null && !user.isActive()) {
                                    response.sendRedirect("/inactive"); // Redirect to the inactive page
                                    return;
                                }
                            for (GrantedAuthority auth : authentication.getAuthorities()) {
                                if (auth.getAuthority().equals("ROLE_USER")) {
                                    response.sendRedirect("/user/home");
                                    return;
                                } else if (auth.getAuthority().equals("ROLE_ADMIN")) {
                                    response.sendRedirect("/admin/listelection");
                                    return;
                                }
                            }
                            // Handle other roles or default redirect
                            response.sendRedirect("/inactive");
                        })
                        .permitAll())
                .logout(logout -> logout
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
           
                        .logoutSuccessUrl("/")
                        .invalidateHttpSession(true)
                        
                        .permitAll())
                .exceptionHandling(handling -> handling
                        .accessDeniedPage("/inactive"));
    }
    
    @GetMapping("/successHandler")
    public String defaultAfterLogin(Authentication authentication) {
     UserService userDetails = (UserService) authentication.getPrincipal();

     String url = "";
     if (userDetails.hasRole("ROLE_ADMIN")) {
       url = "redirect:/admin/listelection";
       // return new ModelAndView("redirect:/admin/home");
   } else if (userDetails.hasRole("ROLE_USER")) {
       url = "redirect:/user/vote";
   }


    return url;
  }


}