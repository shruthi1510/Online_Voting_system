package net.com.springboot.repository;


import net.com.springboot.model.Election;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ElectionRepository extends JpaRepository<Election, Long> {

	Optional<Election> findFirstByOrderById();
}

