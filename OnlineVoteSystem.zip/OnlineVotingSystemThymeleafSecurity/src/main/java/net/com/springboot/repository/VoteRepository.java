package net.com.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.com.springboot.model.Candidate;
import net.com.springboot.model.User;
import net.com.springboot.model.Vote;

@Repository
public interface VoteRepository extends JpaRepository<Vote, Long> {

    boolean existsByUser(User user);

    int countByCandidate(Candidate candidate);

    void deleteByCandidateId(Long candidateId);

	List<Vote> findByCandidateId(Long candidateId);
}
