package net.com.springboot.service;

import net.com.springboot.model.Candidate;
import net.com.springboot.model.Election;

import java.util.List;

public interface ElectionService {
    List<Election> getAllElections();

    Election createElection(Election election);

void addCandidateToElection(Long electionId, Candidate candidate);

List<Candidate> getAllCandidatesInElection(Long electionId);

Election getElectionById(Long id);
List<Candidate> getAllCandidates();
Election findCurrentElection();

void toggleElectionStatus(Long electionId);

Election updateElection(Election existingElection);

void deleteElection(Long id);


}

