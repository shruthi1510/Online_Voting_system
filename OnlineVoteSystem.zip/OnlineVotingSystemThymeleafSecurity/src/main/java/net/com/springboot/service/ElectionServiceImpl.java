package net.com.springboot.service;

import net.com.springboot.model.Candidate;
import net.com.springboot.model.Election;
import net.com.springboot.repository.CandidateRepository;
import net.com.springboot.repository.ElectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ElectionServiceImpl implements ElectionService {

    private final ElectionRepository electionRepository;

    private final CandidateRepository candidateRepository; // Add this line

    @Autowired
    public ElectionServiceImpl(ElectionRepository electionRepository, CandidateRepository candidateRepository) {
        this.electionRepository = electionRepository;
        this.candidateRepository = candidateRepository;
    }
  

    @Override
    public List<Election> getAllElections() {
        return electionRepository.findAll();
    }

    @Override
    public Election createElection(Election election) {
        return electionRepository.save(election);
    }
    @Override
    public void addCandidateToElection(Long electionId, Candidate candidate) {
        Election election = electionRepository.findById(electionId).orElseThrow();
        candidate.setElection(election);
        election.getCandidates().add(candidate);
        electionRepository.save(election);
    }

    @Override
    public List<Candidate> getAllCandidatesInElection(Long electionId) {
        Election election = electionRepository.findById(electionId).orElseThrow();
        return election.getCandidates();
    }

@Override
public Election getElectionById(Long id) {
    return electionRepository.findById(id).orElse(null);
}

@Override
public List<Candidate> getAllCandidates() {
    // Assuming you have a CandidateRepository to retrieve all candidates
    return candidateRepository.findAll();
}
@Override
public Election findCurrentElection() {
    // Find the first election based on your specified criteria
	 return electionRepository.findFirstByOrderById().orElse(null);
}
@Override
public void toggleElectionStatus(Long electionId) {
    Election election = electionRepository.findById(electionId).orElse(null);
    if (election != null) {
        // Toggle election status
        election.toggleStatus();
        electionRepository.save(election);
    }
}
@Override
public Election updateElection(Election election) {
    return electionRepository.save(election);
}


@Override
public void deleteElection(Long id) {
	 electionRepository.deleteById(id);
	
}

}
