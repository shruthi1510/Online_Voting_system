package net.com.springboot.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import net.com.springboot.model.User;
import net.com.springboot.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);

	List<User> getAllUsers();

	User getUserById(Long id);

	void deleteUser(Long id);
	  void toggleUserStatus(Long userId);
	  User updateUser(User user); // Add this method

	boolean validateUserLogin(String username, String password);

	String getUserRole(String username);

	boolean hasRole(String role);

	public Long getCurrentUserId();

	Long getUserIdByUsername(String username);

	User getCurrentUser();

	void resetUserPassword(Long userId, String password);
}
