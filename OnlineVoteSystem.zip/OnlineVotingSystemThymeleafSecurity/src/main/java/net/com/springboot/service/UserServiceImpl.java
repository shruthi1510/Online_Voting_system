package net.com.springboot.service;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import net.com.springboot.model.Role;
import net.com.springboot.model.User;
import net.com.springboot.model.Vote;
import net.com.springboot.repository.UserRepository;
import net.com.springboot.web.dto.UserRegistrationDto;

@Service
public class UserServiceImpl implements UserService{

	private UserRepository userRepository;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoderUser;
	
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}
	 @Override
	    public boolean hasRole(String role) {
	        // Implement logic to check if the authenticated user has the specified role
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        return authentication.getAuthorities().stream()
	                .anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals(role));
	    }
	@Override
	public User save(UserRegistrationDto registrationDto) {
	    User user = new User(
	        registrationDto.getFirstName(),
	        registrationDto.getLastName(),
	        registrationDto.getEmail(),
	        passwordEncoderUser.encode(registrationDto.getPassword()),
	        Arrays.asList(new Role("ROLE_USER"))
	    );
	    user.setActive(false);
	    return userRepository.save(user);
	}
	 @PostConstruct
	    public void createDemoUser() {
	        // Check if the demo user already exists
	        if (userRepository.findByEmail("Demo1@gmail.com") == null) {

	            User demoUser = new User(
	           "Demo1",
	            "Demo",
	            "Demo1@gmail.com",
	            passwordEncoderUser.encode("Demo1@123"),
	    	    Arrays.asList(new Role("ROLE_ADMIN")));
	            demoUser.setActive(true);
	    	


	            // Save the demo user
	            userRepository.save(demoUser);
	        }
	    }

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	
		User user = userRepository.findByEmail(username);
		if(user == null) {
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		   if (!user.isActive()) {
		        throw new DisabledException("User is not active.");
		    }
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), mapRolesToAuthorities(user.getRoles()));		
	}
	
	private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles){
		return roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());
	}

	  public List<User> getAllUsers() {
	        return userRepository.findAll();
	    }

	    public User getUserById(Long id) {
	        return userRepository.findById(id).orElse(null);
	    }

	    public User updateUser(User user) {
	        return userRepository.save(user);
	    }

	    public void resetUserPassword(Long id, String newPassword) {
	        User user = userRepository.findById(id).orElse(null);
	        if (user != null) {
	            user.setPassword(passwordEncoderUser.encode(newPassword));
	            userRepository.save(user);
	        }
	    }

	
	    
	    
	    @Override
	    public void toggleUserStatus(Long userId) {
	        User user = userRepository.findById(userId).orElse(null);
	        if (user != null) {
	            // Toggle user status (activate/deactivate)
	            user.setActive(!user.isActive());
	            userRepository.save(user);
	        }
	    }
	    public boolean validateUserLogin(String username, String password) {
	        User user = userRepository.findByEmail(username);
	        return user != null && passwordEncoderUser.matches(password, user.getPassword());
	    }
	    public String getUserRole(String username) {
	        User user = userRepository.findByEmail(username);
	        if (user != null) {
	            // Assuming a user has a single role for simplicity. Adjust as needed for your application.
	            return user.getRoles().stream().findFirst().map(Role::getName).orElse(null);
	        }
	        return null;
	    }
	    

	    public Long getCurrentUserId() {
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

	        if (authentication == null || !authentication.isAuthenticated()) {
	            // No authenticated user
	            return null;
	        }

	        Object principal = authentication.getPrincipal();

	        if (principal instanceof UserDetails) {
	            // Authenticated user with UserDetails (typically the case for Spring Security)
	            User user = (User) principal;
	            return user.getId();
	        }

	        // Unable to determine the user ID
	        return null;
	    }
	    public Long getUserIdByUsername(String username) {
	        User user = userRepository.findByEmail(username);
	        return (user != null) ? user.getId() : null;
	    }



	    @Override
	    public User getCurrentUser() {
	        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
	        if (authentication == null || !authentication.isAuthenticated()) {
	            return null;
	        }

	        Object principal = authentication.getPrincipal();

	        if (principal instanceof UserDetails) {
	            return userRepository.findByEmail(((UserDetails) principal).getUsername());
	        }

	        return null;
	    }
	    @Transactional
	    public void deleteUser(Long userId) {
	        User user = userRepository.findById(userId).orElseThrow(() -> new EntityNotFoundException("User not found"));

	        // Remove the user from associated votes to prevent foreign key constraint violation
	        List<Vote> userVotes = user.getVotes();
	        for (Vote vote : userVotes) {
	            vote.setUser(null);
	        }

	        // Clear the votes list from the user
	        userVotes.clear();

	        // Delete the user
	        userRepository.deleteById(userId);
	    }
}
