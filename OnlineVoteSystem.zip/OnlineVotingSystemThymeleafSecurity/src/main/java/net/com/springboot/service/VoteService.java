package net.com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.com.springboot.model.Candidate;
import net.com.springboot.model.Election;
import net.com.springboot.model.User;
import net.com.springboot.model.Vote;
import net.com.springboot.repository.CandidateRepository;
import net.com.springboot.repository.UserRepository;
import net.com.springboot.repository.VoteRepository;

@Service
public class VoteService {

    private final VoteRepository voteRepository;
    private final UserRepository userRepository;
    private final CandidateRepository candidateRepository;

    @Autowired
    public VoteService(VoteRepository voteRepository, UserRepository userRepository,
                       CandidateRepository candidateRepository) {
        this.voteRepository = voteRepository;
        this.userRepository = userRepository;
        this.candidateRepository = candidateRepository;
    }

    @Transactional
    public void castVote(Long userId, Long candidateId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        Candidate candidate = candidateRepository.findById(candidateId).orElseThrow(() -> new RuntimeException("Candidate not found"));

        // Check if the user has already voted
        if (hasUserVoted(user)) {
            throw new RuntimeException("User has already voted");
        }

        // Check if the election is active
        Election election = candidate.getElection();
        if (election == null || !"ACTIVE".equals(election.getStatus())) {
            throw new RuntimeException("Voting is not allowed for inactive elections");
        }

        // Create and save the vote
        Vote vote = new Vote();
        vote.setUser(user);
        vote.setCandidate(candidate);
        voteRepository.save(vote);
    }

    public int getVoteCountForCandidate(Long candidateId) {
        Candidate candidate = candidateRepository.findById(candidateId).orElseThrow(() -> new RuntimeException("Candidate not found"));
        return voteRepository.countByCandidate(candidate);
    }

    private boolean hasUserVoted(User user) {
        return voteRepository.existsByUser(user);
    }
    @Transactional
    public List<Vote> deleteVotesByCandidate(Long candidateId) {
        List<Vote> votes = voteRepository.findByCandidateId(candidateId);

        for (Vote vote : votes) {
            User user = vote.getUser();
            user.getVotes().remove(vote);
        }

        // Delete the votes after removing them from associated users
        voteRepository.deleteAll(votes);

        return votes;
    }


}
