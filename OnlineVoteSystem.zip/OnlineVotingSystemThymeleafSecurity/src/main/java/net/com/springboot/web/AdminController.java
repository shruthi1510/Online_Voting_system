package net.com.springboot.web;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import net.com.springboot.model.User;
import net.com.springboot.service.UserService;
import net.com.springboot.service.VoteService;
import net.com.springboot.model.Candidate;
import net.com.springboot.model.Election;
import net.com.springboot.service.ElectionService;


@Controller
@RequestMapping("/admin")
public class AdminController {

	
    @Autowired
    private UserService userService;

    @Autowired
    private final ElectionService electionService;
    @Autowired
    private final VoteService voteService;
    @Autowired
    public AdminController(ElectionService electionService,VoteService voteService,UserService userService) {
        this.electionService = electionService;
        this.voteService = voteService;
        this.userService = userService;
    }


 
    
    @GetMapping("/listelection")
    public String listElections(Model model) {
        List<Election> elections = electionService.getAllElections();
        model.addAttribute("elections", elections);
        return "listelection";
    }

    @GetMapping("/createElection")
    public String showCreateElectionForm(Election election) {
        return "createElection";
    }

    @PostMapping("/createElection")
    public String createElection(@ModelAttribute("election") Election election, BindingResult bindingResult) {
        // Validate start date and end date
        if (election.getStartDate().after(election.getEndDate())) {
            bindingResult.rejectValue("endDate", "error.election", "End date must be after start date");
        }

        // Validate end date against the current date
        if (election.getEndDate().before(new Date())) {
            bindingResult.rejectValue("endDate", "error.election", "End date must be in the future");
        }

        // If there are validation errors, return to the form
        if (bindingResult.hasErrors()) {
            return "createElection";
        }

        electionService.createElection(election);
        return "redirect:/admin/listelection";
    }

    @GetMapping("/editElection/{id}")
    public String showEditElectionForm(@PathVariable Long id, Model model) {
        Election election = electionService.getElectionById(id);
        model.addAttribute("election", election);
        return "editElection";
    }

    @PostMapping("/editElection/{id}")
    public String editElection(@PathVariable Long id, @ModelAttribute("election") Election editedElection) {
        Election existingElection = electionService.getElectionById(id);

        // Update election details
        existingElection.setTitle(editedElection.getTitle());
        existingElection.setDescription(editedElection.getDescription());
        // Add more fields as needed

        electionService.updateElection(existingElection);

        return "redirect:/admin/listelection";
    }
    @Transactional
    @GetMapping("/deleteElection/{id}")
    public String deleteElection(@PathVariable Long id) {
    	  List<Candidate> candidates = electionService.getAllCandidatesInElection(id);
    	    for (Candidate candidate : candidates) {
    	        voteService.deleteVotesByCandidate(candidate.getId());
    	    }
        electionService.deleteElection(id);
        return "redirect:/admin/listelection";
    }

    @GetMapping("/listcandidates/{electionId}")
    public String listCandidatesInElection(@PathVariable Long electionId, Model model) {
        List<Candidate> candidates = electionService.getAllCandidatesInElection(electionId);
        model.addAttribute("candidates", candidates);
        return "listCandidates";
    }
    @GetMapping("/listAllCandidates")
    public String listAllCandidates(Model model) {
        List<Candidate> candidates = electionService.getAllCandidates(); // Assuming getAllCandidates() method exists in ElectionService
        model.addAttribute("candidates", candidates);
        return "listAllCandidates";
    }
@GetMapping("/addCandidate/{electionId}")
public String showAddCandidateForm(@PathVariable Long electionId, Model model) {
    Election election = electionService.getElectionById(electionId);
    Candidate candidate = new Candidate();
    model.addAttribute("electionId", electionId);
    model.addAttribute("election", election);
    model.addAttribute("candidate", candidate);
    return "addCandidate";
}
@PostMapping("/addCandidate/{electionId}")
public String addCandidateToElection(
        @PathVariable Long electionId,
        @ModelAttribute("candidate") Candidate candidate) {
    electionService.addCandidateToElection(electionId, candidate);
    return "redirect:/admin/listelection";
}



@GetMapping("/candidates/vote-count")
public String displayVoteCount(Model model) {
    // Assuming you have a method in CandidateService to get all candidates
    // Adjust this based on your actual implementation
    List<Candidate> candidates = electionService.getAllCandidates();

    // Create a map to store candidate names and their respective vote counts
    Map<String, Integer> voteCounts = new HashMap<>();

    // Populate the map with candidate names and their vote counts
    for (Candidate candidate : candidates) {
        int voteCount = voteService.getVoteCountForCandidate(candidate.getId());
        voteCounts.put(candidate.getName(), voteCount);
    }

    model.addAttribute("voteCounts", voteCounts);

    return "admin-vote-count"; 
}




@GetMapping("/users")
public String showAllUsers(Model model) {
    List<User> users = userService.getAllUsers();
    model.addAttribute("users", users);
    return "admin-users";
}

@GetMapping("/users/edit/{id}")
public String showEditUserForm(@PathVariable("id") Long userId, Model model) {
    User user = userService.getUserById(userId);
    model.addAttribute("user", user);
    return "admin-edit-user";
}

@PostMapping("/users/edit/{id}")
public String editUser(@PathVariable("id") Long userId, @ModelAttribute("user") User editedUser) {
    User existingUser = userService.getUserById(userId);

    // Update user details
    existingUser.setFirstName(editedUser.getFirstName());
    existingUser.setLastName(editedUser.getLastName());
    existingUser.setEmail(editedUser.getEmail());

    userService.updateUser(existingUser);

    return "redirect:/admin/users";
}
@GetMapping("/users/delete/{id}")
public String deleteUser(@PathVariable("id") Long userId) {
    userService.deleteUser(userId);
    return "redirect:/admin/users";
}
@GetMapping("/users/toggle-status/{id}")
public String toggleUserStatus(@PathVariable("id") Long userId) {
    userService.toggleUserStatus(userId);
    return "redirect:/admin/users";
}


@GetMapping("/elections/toggle-status/{id}")
public String toggleElectionStatus(@PathVariable("id") Long electionId) {
    electionService.toggleElectionStatus(electionId);
    return "redirect:/admin/listelection";
}

@GetMapping("/users/{id}/reset-password")
public String showResetPasswordForm(@PathVariable Long id, Model model) {
    // Assuming you have a method to retrieve the user by ID
    User user = userService.getUserById(id);

    // Add the user object to the model
    model.addAttribute("user", user);

    return "user-reset-password";
}

// POST Mapping: Handle the password reset
@PostMapping("/users/{id}/reset-password")
public String resetPassword(@PathVariable("id") Long userId, @ModelAttribute("user") User user) {
    // Assuming you have a method to update the user password in the UserService
    userService.resetUserPassword(userId, user.getPassword());

    // Redirect to a success page or display a success message
    return "redirect:/admin/users";
}
}
    
    
