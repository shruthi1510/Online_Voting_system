package net.com.springboot.web;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import net.com.springboot.model.Candidate;
import net.com.springboot.model.Election;
import net.com.springboot.model.User;

import net.com.springboot.service.ElectionService;
import net.com.springboot.service.UserService;
import net.com.springboot.service.VoteService;

@Controller
public class MainController {

	 @Autowired
	    private UserService userService;

	    @Autowired
	    private final ElectionService electionService;
	    @Autowired
	    private final VoteService voteService;
	    @Autowired
	    public MainController(ElectionService electionService,VoteService voteService,UserService userService) {
	        this.electionService = electionService;
	        this.voteService = voteService;
	        this.userService = userService;
	    }
	
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	@GetMapping("/logout")
	public String logout(){
		return "redirect:/";
	}
	
	@GetMapping("/login")
	public String loginPage(@RequestParam(name = "role", defaultValue = "Voter") String role, Model model) {
	    model.addAttribute("role", role);
	    return "login"; // Assuming your login page is named "login.html"
	}
	
	@PostMapping("/login")
	public String loginPost(@RequestParam String username, @RequestParam String password) {
	    // Validate user credentials
	    boolean isValidUser = userService.validateUserLogin(username, password);

	    if (isValidUser) {
	        // Retrieve user role after successful login
	        String userRole = userService.getUserRole(username);
System.out.println(userRole);
	        // Redirect based on user role
	        if ("ROLE_ADMIN".equals(userRole)) {
	        	System.out.println("ROLE_ADMIN granted");
	            // Redirect to the admin index after successful login
	            return "listelection";
	        } else if ("ROLE_USER".equals(userRole)) {
	            // Redirect to the user index after successful login
	            return "index";
	        } else {
	            // Handle other roles if needed
	            return "redirect:/access-denied";
	        }
	    } else {
	        // Redirect to login page with an error message
	        return "redirect:/access-denied";
	    }
	}
	  @GetMapping("/user/home")
	    public String homePage() {
	        return "user/home";
	    }

	 
	  @GetMapping("/user/elections")
	  public String viewActiveElections(Model model) {
	      List<Election> activeElections = electionService.getAllElections().stream()
	              .filter(election -> "ACTIVE".equals(election.getStatus()))
	              .collect(Collectors.toList());

	      model.addAttribute("elections", activeElections);
	      return "user/elections";
	  }
	    @GetMapping("/user/vote/{electionId}")
	    public String votePage(@PathVariable Long electionId, Model model) {
	        Election election = electionService.getElectionById(electionId);
	       
	        List<Candidate> candidates = election.getCandidates();
	        model.addAttribute("electionId", electionId);
	        model.addAttribute("election", election);
	        model.addAttribute("candidates", candidates);
	        return "user/vote";
	    }
	    @PostMapping("/user/vote/{electionId}")
	    public String vote(@PathVariable Long electionId, @RequestParam Long candidateId, HttpSession session) {
	        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

	        if (userDetails == null) {
	            return "redirect:/login";
	        }

	        String username = userDetails.getUsername();
	        Long userId = userService.getUserIdByUsername(username);

	        try {
	            voteService.castVote(userId, candidateId);
	        } catch (RuntimeException e) {
	            // Handle the case where the user has already casted a vote
	            return "redirect:/user/already-casted";
	        }

	        return "redirect:/user/elections";
	    }
	    
	    @GetMapping("/user/already-casted")
	    public String alreadyCasted(){
	  	  return "user/already-casted";
	    }

  @GetMapping("/inactive")
  public String inactive(){
	  return "inactive";
  }

}
